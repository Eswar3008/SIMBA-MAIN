using Microsoft.UI.Xaml;

namespace SIMBA.UI;

public partial class ColorPaletteOverride : ResourceDictionary
{
	public ColorPaletteOverride()
	{
		this

			;
	}
}